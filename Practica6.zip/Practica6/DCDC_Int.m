% Resolver la integral
[t,x] = ode45(@DCDC,[0 0.01], [0 0]);

% Gráfica de la corriente del inductor
figure(1)
plot(t, x(:,1), 'b', 'LineWidth', 1.5);
grid on
title("Corriente del Inductor (I)");
xlabel("Tiempo (s)");
ylabel("Ampers (A)");  

% Gráfica del voltaje de salida
figure(2)
plot(t, x(:,2), 'k', 'LineWidth', 1.5); 
grid on
title("Voltaje de Salida (V)");
xlabel("Tiempo (s)");
ylabel("Voltios (V)");  
